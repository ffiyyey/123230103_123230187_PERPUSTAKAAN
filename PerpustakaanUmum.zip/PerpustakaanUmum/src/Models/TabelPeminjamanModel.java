package Models;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author aliad
 */
public class TabelPeminjamanModel extends AbstractTableModel{
    List<PeminjamanModel> dataPeminjaman;

    public TabelPeminjamanModel(List<PeminjamanModel> dataPeminjaman) {
        this.dataPeminjaman = dataPeminjaman;
    }

    @Override
    public int getRowCount() {
        return dataPeminjaman.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "ID Peminjaman";
            case 1:
                return "Nama Anggota";
            case 2:
                return "Nama Buku";
            case 3:
                return "Tanggal Peminjaman";
            case 4:
                return "Tanggal Pengembalian";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return dataPeminjaman.get(rowIndex).getId();
            case 1:
                return dataPeminjaman.get(rowIndex).getNama_anggota();
            case 2:
                return dataPeminjaman.get(rowIndex).getNama_buku();
            case 3:
                return dataPeminjaman.get(rowIndex).getTanggal_pinjam();
            case 4:
                return dataPeminjaman.get(rowIndex).getTanggal_kembali();
            default:
                return null;
        }
    }

}
