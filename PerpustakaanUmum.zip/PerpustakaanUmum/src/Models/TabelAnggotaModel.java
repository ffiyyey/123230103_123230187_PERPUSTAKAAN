package Models;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author aliad
 */
public class TabelAnggotaModel extends AbstractTableModel {

    List<AnggotaModel> dataAnggota;

    public TabelAnggotaModel(List<AnggotaModel> dataAnggota) {
        this.dataAnggota = dataAnggota;
    }

    @Override
    public int getRowCount() {
        return dataAnggota.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "ID Anggota";
            case 1:
                return "Nama";
            case 2:
                return "Alamat";
            case 3:
                return "No Hp";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return dataAnggota.get(rowIndex).getId();
            case 1:
                return dataAnggota.get(rowIndex).getNama();
            case 2:
                return dataAnggota.get(rowIndex).getAlamat();
            case 3:
                return dataAnggota.get(rowIndex).getNo_hp();
            default:
                return null;
        }
    }

}
