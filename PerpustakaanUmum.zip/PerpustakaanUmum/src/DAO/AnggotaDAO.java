package DAO;

import DAOImplements.AnggotaImplement;
import Koneksi.Connector;
import Models.AnggotaModel;
import Models.BukuModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aliad
 */
public class AnggotaDAO implements AnggotaImplement {

    Connection connection;

    final String showQuery = "SELECT * FROM anggota";
    final String insertQuery = "INSERT INTO anggota (nama, alamat, no_hp) VALUES (?, ?, ?)";
    final String editQuery = "UPDATE anggota SET nama = ?, alamat = ?, no_hp = ? WHERE id = ?";
    final String deleteQuery = "DELETE FROM anggota WHERE id = ?";

    public AnggotaDAO() {
        this.connection = Connector.connection();
    }

    @Override
    public void tambahAnggota(AnggotaModel dataAnggota) {
        PreparedStatement prepStatement = null;

        try {
            prepStatement = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            prepStatement.setString(1, dataAnggota.getNama());
            prepStatement.setString(2, dataAnggota.getAlamat());
            prepStatement.setString(3, dataAnggota.getNo_hp());
            prepStatement.executeUpdate();

            ResultSet result = prepStatement.getGeneratedKeys();
            while (result.next()) {
                dataAnggota.setId(result.getInt(1));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                prepStatement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void editAnggota(AnggotaModel dataAnggota) {
        PreparedStatement prepStatement = null;

        try {
            prepStatement = connection.prepareStatement(editQuery);
            prepStatement.setString(1, dataAnggota.getNama());
            prepStatement.setString(2, dataAnggota.getAlamat());
            prepStatement.setString(3, dataAnggota.getNo_hp());
            prepStatement.setInt(4, dataAnggota.getId());
            prepStatement.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                prepStatement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    @Override
    public void hapusAnggota(int idAnggota) {
        PreparedStatement prepStatement = null;

        try {
            prepStatement = connection.prepareStatement(deleteQuery);
            prepStatement.setInt(1, idAnggota);
            prepStatement.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                prepStatement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<AnggotaModel> showAllAnggota() {
        List<AnggotaModel> dataAnggota = null;

        try {
            dataAnggota = new ArrayList<AnggotaModel>();
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(showQuery);

            while (result.next()) {
                AnggotaModel anggota = new AnggotaModel();
                anggota.setId(result.getInt("id"));
                anggota.setNama(result.getString("nama"));
                anggota.setAlamat(result.getString("alamat"));
                anggota.setNo_hp(result.getString("no_hp"));

                dataAnggota.add(anggota);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AnggotaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dataAnggota;
    }

    @Override
    public List<AnggotaModel> cariAnggota(String keyword) {
        final String searchQuery = "SELECT * FROM anggota WHERE nama LIKE ?";
        PreparedStatement prepStatement = null;
        List<AnggotaModel> dataAnggotaCari = null;
        try {
            dataAnggotaCari = new ArrayList<AnggotaModel>();
            String kataCari = "%" + keyword + "%";
            prepStatement = connection.prepareStatement(searchQuery);

            prepStatement.setString(1, kataCari);

            ResultSet result = prepStatement.executeQuery();
            while (result.next()) {
                AnggotaModel anggotaCari = new AnggotaModel();

                anggotaCari.setId(result.getInt("id"));
                anggotaCari.setNama(result.getString("nama"));
                anggotaCari.setAlamat(result.getString("alamat"));
                anggotaCari.setNo_hp(result.getString("no_hp"));

                dataAnggotaCari.add(anggotaCari);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return dataAnggotaCari;
    }
}