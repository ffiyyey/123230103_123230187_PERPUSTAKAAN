package DAO;

import Koneksi.Connector;
import Models.PeminjamanModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import DAOImplements.PeminjamanImpelement;

/**
 *
 * @author aliad
 */
public class PeminjamanDAO implements PeminjamanImpelement {

    Connection connection;
    final String showQuery = "SELECT p.id, p.id_anggota, a.nama AS nama_anggota, p.id_buku, b.judul AS nama_buku, p.tanggal_pinjam, p.tanggal_kembali\n"
            + "FROM pinjam p\n"
            + "INNER JOIN anggota a ON p.id_anggota = a.id\n"
            + "INNER JOIN buku b ON p.id_buku = b.id";
    final String insertQuery = "INSERT INTO pinjam (id_anggota, id_buku, tanggal_pinjam, tanggal_kembali) VALUES (?, ?, ?, ?)";

    public PeminjamanDAO() {
        this.connection = Connector.connection();
    }

    @Override
    public void insertPeminjaman(PeminjamanModel dataPinjam) {
        PreparedStatement prepStatement = null;

        try {
            prepStatement = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            prepStatement.setInt(1, dataPinjam.getId_anggota());
            prepStatement.setInt(2, dataPinjam.getId_buku());
            prepStatement.setString(3, dataPinjam.getTanggal_pinjam());
            prepStatement.setString(4, dataPinjam.getTanggal_kembali());
            prepStatement.executeUpdate();

            ResultSet result = prepStatement.getGeneratedKeys();
            while (result.next()) {
                dataPinjam.setId(result.getInt(1));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                prepStatement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<PeminjamanModel> showAllPeminjaman() {
        List<PeminjamanModel> dataPeminjaman = null;

        try {
            dataPeminjaman = new ArrayList<PeminjamanModel>();
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(showQuery);

            while (result.next()) {
                PeminjamanModel peminjaman = new PeminjamanModel();
                peminjaman.setId(result.getInt("id"));
                peminjaman.setId_anggota(result.getInt("id_anggota"));
                peminjaman.setNama_anggota(result.getString("nama_anggota")); // Nama anggota
                peminjaman.setId_buku(result.getInt("id_buku"));
                peminjaman.setNama_buku(result.getString("nama_buku")); // Nama buku
                peminjaman.setTanggal_pinjam(result.getString("tanggal_pinjam"));
                peminjaman.setTanggal_kembali(result.getString("tanggal_kembali"));

                dataPeminjaman.add(peminjaman);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PeminjamanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dataPeminjaman;
    }

}
