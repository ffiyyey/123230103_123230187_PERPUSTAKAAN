package DAO;
import Koneksi.Connector;
import Models.AdminModel;
import DAOImplements.AdminImplement;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
/**
 *
 * @author aliad
 */
public class AdminDAO implements AdminImplement{
    Connection connection;
    final String queryCheckAdmin = "SELECT * FROM admin WHERE username = ? AND password = ?";
    
    @Override
    public boolean checkAdmin(String username, String password) {
        boolean check = false;
        try {
            PreparedStatement prepStatement = connection.prepareStatement(queryCheckAdmin);
            prepStatement.setString(1, username);
            prepStatement.setString(2, password);
            
            ResultSet result = prepStatement.executeQuery();
            if (result.next()) {
                check = true;
            }
        } catch (SQLException ex) {
            check = false;
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return check;
    }

    public AdminDAO() {
        this.connection = Connector.connection();
    }
}
