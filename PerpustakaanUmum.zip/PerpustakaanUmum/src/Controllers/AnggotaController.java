package Controllers;

import DAO.AnggotaDAO;
import DAO.BukuDAO;
import DAOImplements.AnggotaImplement;
import Models.AnggotaModel;
import Models.TabelAnggotaModel;
import Views.AnggotaView;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aliad
 */
public class AnggotaController {

    AnggotaView anggotaFrame;
    AnggotaImplement implementAnggota;
    List<AnggotaModel> dataAnggota;

    public AnggotaController(AnggotaView anggotaFrame) {
        this.anggotaFrame = anggotaFrame;
        implementAnggota = new AnggotaDAO();
        dataAnggota = implementAnggota.showAllAnggota();
    }

    public void loadDataTabel() {
        dataAnggota = implementAnggota.showAllAnggota();
        TabelAnggotaModel tabelDataBuku = new TabelAnggotaModel(dataAnggota);
        anggotaFrame.getTabelDataAnggota().setModel(tabelDataBuku);
    }

    public void insertDataTabel() {
        AnggotaModel anggota = new AnggotaModel();

        anggota.setNama(anggotaFrame.getTxtNama().getText());
        anggota.setAlamat(anggotaFrame.getTxtAlamat().getText());
        anggota.setNo_hp(anggotaFrame.getTxtNoHp().getText());

        if (anggota.getNama().equals("") || anggota.getAlamat().equals("") || anggota.getNo_hp().equals("")) {
            JOptionPane.showMessageDialog(anggotaFrame, "Mohon Isi Secara Lengkap Data Anggota Yang Ingin Ditambahkan");
            return;
        }

        implementAnggota.tambahAnggota(anggota);
        JOptionPane.showMessageDialog(anggotaFrame, "Data anggota berhasil ditambahkan");
    }

    public void editDataTabel() {
        AnggotaModel anggota = new AnggotaModel();

        String idEdit = anggotaFrame.getTxtID().getText();
        if (idEdit.isEmpty()) {
            JOptionPane.showMessageDialog(anggotaFrame, "Pilih Data Anggota Yang Ingin Diedit");
            return;
        }
        anggota.setId(Integer.parseInt(idEdit));
        anggota.setNama(anggotaFrame.getTxtNama().getText());
        anggota.setAlamat(anggotaFrame.getTxtAlamat().getText());
        anggota.setNo_hp(anggotaFrame.getTxtNoHp().getText());

        if (anggota.getNama().equals("") || anggota.getAlamat().equals("") || anggota.getNo_hp().equals("")) {
            JOptionPane.showMessageDialog(anggotaFrame, "Mohon Isi Secara Lengkap Data Anggota Yang Ingin Diedit");
            return;
        }

        implementAnggota.editAnggota(anggota);
        JOptionPane.showMessageDialog(anggotaFrame, "Data Anggota Dengan ID " + anggota.getId() + " Berhasil Diedit");
    }

    public void deleteDataTabel() {
        String idDelete = anggotaFrame.getTxtID().getText();
        if (idDelete.isEmpty()) {
            JOptionPane.showMessageDialog(anggotaFrame, "Pilih Anggota Yang Ingin Dihapus");
            return;
        }
        int idAnggota = Integer.parseInt(idDelete);

        int confirmDelete = JOptionPane.showConfirmDialog(anggotaFrame, "Apakah Anda Yakin Ingin Menghapus Anggota Dengan Nama " + anggotaFrame.getTxtNama().getText() + " ?");
        if (confirmDelete == JOptionPane.YES_OPTION) {
            implementAnggota.hapusAnggota(idAnggota);
        }
    }

    public void searchDataTabel(String keyword) {
        if (keyword.equals("")) {
            JOptionPane.showMessageDialog(anggotaFrame, "Masukkan Keyword Yang Ingin Dicari");
            return;
        }
        List<AnggotaModel> dataAnggotaCari = new ArrayList<AnggotaModel>();
        dataAnggotaCari = implementAnggota.cariAnggota(keyword);
        TabelAnggotaModel tabelDataAnggotaCari = new TabelAnggotaModel(dataAnggotaCari);
        anggotaFrame.getTabelDataAnggota().setModel(tabelDataAnggotaCari);
    }
}
