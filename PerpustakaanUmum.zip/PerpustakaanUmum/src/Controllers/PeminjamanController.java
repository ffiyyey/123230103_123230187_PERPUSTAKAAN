package Controllers;

import DAO.AnggotaDAO;
import DAO.BukuDAO;
import DAO.PeminjamanDAO;
import DAOImplements.AnggotaImplement;
import DAOImplements.BukuImplement;
import DAOImplements.PeminjamanImpelement;
import Koneksi.Connector;
import Models.AnggotaModel;
import Models.BukuModel;
import Models.PeminjamanModel;
import Models.TabelAnggotaModel;
import Models.TabelPeminjamanModel;
import Views.ShowPeminjamanView;
import Views.InputPeminjamanView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aliad
 */
public class PeminjamanController {

    InputPeminjamanView inputFrame;
    ShowPeminjamanView showFrame;
    PeminjamanImpelement implementPeminjaman;
    BukuImplement implementBuku;
    AnggotaImplement implementAnggota;
    List<PeminjamanModel> dataPeminjaman;
    List<AnggotaModel> dataAnggota;

    public PeminjamanController(InputPeminjamanView inputFrame) {
        this.inputFrame = inputFrame;
        implementPeminjaman = new PeminjamanDAO();
        implementBuku = new BukuDAO();
        implementAnggota = new AnggotaDAO();
        loadBukuToComboBox();

        inputFrame.getCbBukuPinjam().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedJudulBuku = (String) inputFrame.getCbBukuPinjam().getSelectedItem();
                if (selectedJudulBuku != null) {
                    BukuModel buku = implementBuku.getBukuByJudul(selectedJudulBuku);
                    PeminjamanModel pinjam = new PeminjamanModel();
                    pinjam.setId_buku(buku.getId());
                }
            }
        });
    }

    public PeminjamanController(ShowPeminjamanView showFrame) {
        this.showFrame = showFrame;
        implementPeminjaman = new PeminjamanDAO();
        dataPeminjaman = implementPeminjaman.showAllPeminjaman();

    }

    public void loadDataTabelAnggota() {
        dataAnggota = implementAnggota.showAllAnggota();
        TabelAnggotaModel tableDataAnggota = new TabelAnggotaModel(dataAnggota);
        inputFrame.getTabelDataAnggota().setModel(tableDataAnggota);
    }
    public void loadDataPeminjaman() {
        dataPeminjaman = implementPeminjaman.showAllPeminjaman();
        TabelPeminjamanModel tabelPeminjamanModel = new TabelPeminjamanModel(dataPeminjaman);
        showFrame.getTabelDataPeminjaman().setModel(tabelPeminjamanModel);
    }

    public void loadBukuToComboBox() {
        List<BukuModel> daftarBuku = implementBuku.showAllBuku();

        inputFrame.getCbBukuPinjam().removeAllItems();

        // Menambahkan judul buku ke ComboBox
        for (BukuModel buku : daftarBuku) {
            inputFrame.getCbBukuPinjam().addItem(buku.getJudul());
        }
    }

    // Menangani aksi pemilihan buku dari ComboBox
    public void insertDataTabel() {
        PeminjamanModel pinjam = new PeminjamanModel();
        pinjam.setId_anggota(Integer.parseInt(inputFrame.getTxtIdAnggota().getText()));
        pinjam.setTanggal_pinjam(inputFrame.getTxtDatePinjam().getText());
        pinjam.setTanggal_kembali(inputFrame.getTxtDatePengembalian().getText());

        String selectedJudulBuku = (String) inputFrame.getCbBukuPinjam().getSelectedItem();
        BukuModel buku = implementBuku.getBukuByJudul(selectedJudulBuku);
        pinjam.setId_buku(buku.getId());

        implementPeminjaman.insertPeminjaman(pinjam);
        JOptionPane.showMessageDialog(inputFrame, "Data Peminjaman berhasil ditambahkan");
    }

    public List<AnggotaModel> searchAnggota(String keyword) {
        final String searchQuery = "SELECT * FROM anggota WHERE nama LIKE ?";
        Connection connection;
        connection = Connector.connection();
        
        PreparedStatement prepStatement = null;
        List<AnggotaModel> dataAnggotaCari = null;
        try {
            dataAnggotaCari = new ArrayList<AnggotaModel>();
            String kataCari = "%" + keyword + "%";
            prepStatement = connection.prepareStatement(searchQuery);

            prepStatement.setString(1, kataCari);

            ResultSet result = prepStatement.executeQuery();
            while (result.next()) {
                AnggotaModel anggotaCari = new AnggotaModel();

                anggotaCari.setId(result.getInt("id"));
                anggotaCari.setNama(result.getString("nama"));
                anggotaCari.setAlamat(result.getString("alamat"));
                anggotaCari.setNo_hp(result.getString("no_hp"));

                dataAnggotaCari.add(anggotaCari);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return dataAnggotaCari;
    }
}
