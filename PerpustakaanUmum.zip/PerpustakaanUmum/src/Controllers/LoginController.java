package Controllers;

import DAOImplements.AdminImplement;
import Views.LoginView;
import Koneksi.Connector;
import Models.AdminModel;
import DAO.AdminDAO;
import Views.BukuView;
import Views.HomeView;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aliad
 */
public class LoginController {

    LoginView loginFrame;
    AdminImplement implementAdmin;

    public LoginController(LoginView loginFrame) {
        this.loginFrame = loginFrame;
        implementAdmin = new AdminDAO();
    }

    public void checkAdmin(String username, String password) {
        boolean lanjut = false;
        lanjut = implementAdmin.checkAdmin(username, password);
        if (lanjut) {
            new HomeView().setVisible(true);
            loginFrame.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(loginFrame, "Username tidak ditemukan");
        }
    }

}
