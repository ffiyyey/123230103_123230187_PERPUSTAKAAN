package DAOImplements;

import Models.PeminjamanModel;
import java.util.List;

/**
 *
 * @author aliad
 */
public interface PeminjamanImpelement {
    public void insertPeminjaman(PeminjamanModel dataPinjam);
    public List<PeminjamanModel> showAllPeminjaman();
}
