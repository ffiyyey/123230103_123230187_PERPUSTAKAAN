package DAOImplements;

import Models.AnggotaModel;
import java.util.List;

/**
 *
 * @author aliad
 */
public interface AnggotaImplement {
    public void tambahAnggota(AnggotaModel dataAnggota);
    public void editAnggota(AnggotaModel dataAnggota);
    public void hapusAnggota(int idAnggota);
    public List<AnggotaModel> showAllAnggota();
    public List<AnggotaModel> cariAnggota(String keyword);
}
