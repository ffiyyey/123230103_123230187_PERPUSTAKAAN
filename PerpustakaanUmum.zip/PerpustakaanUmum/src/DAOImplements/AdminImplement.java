package DAOImplements;

import Models.AdminModel;

/**
 *
 * @author aliad
 */
public interface AdminImplement {
    public boolean checkAdmin(String username, String password);
}
