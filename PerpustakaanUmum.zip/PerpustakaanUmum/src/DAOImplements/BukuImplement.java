package DAOImplements;
import Models.*;
import java.util.List;
/**
 *
 * @author aliad
 */
public interface BukuImplement {
    public void tambahBuku(BukuModel dataBuku);
    public void editBuku(BukuModel dataBuku);
    public void hapusBuku(int idBuku);
    public BukuModel getBukuByJudul(String judul);
    public List<BukuModel> showAllBuku();
    public List<BukuModel> cariBuku(String keyword, String kategori);
}
